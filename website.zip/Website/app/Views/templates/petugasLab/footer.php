<footer class="bg-blue-800 text-white py-3 mt-10">
    <div class="container mx-auto text-center text-sm">
        &copy; <?= date('Y') ?> Sistem Laboratorium | Medical Checkup
    </div>
</footer>
</body>

</html>
