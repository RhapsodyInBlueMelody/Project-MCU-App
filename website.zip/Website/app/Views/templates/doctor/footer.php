        </main>
        </div>
        </div>
        <!-- Only necessary JS for alert auto-hide -->
        <script>
            setTimeout(function() {
                const alerts = document.querySelectorAll('.alert-dismissible');
                alerts.forEach(function(alert) {
                    alert.style.display = 'none';
                });
            }, 5000);
        </script>
        </body>

        </html>
