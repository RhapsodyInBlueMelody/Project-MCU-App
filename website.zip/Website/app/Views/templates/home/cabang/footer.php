<footer class=<?php echo $color ?> ." text-white py-4 mt-10">
    <div class="max-w-6xl mx-auto px-4 text-center text-sm">
        © 2025 <?php echo $title ?>. All rights reserved.
    </div>
</footer>

</body>
</html>